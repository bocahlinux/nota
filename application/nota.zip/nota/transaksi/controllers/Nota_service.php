<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Nota_service extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//$this->load->model('Mod_transaksi','Transaksi');
		$this->load->model('Home/Mod_home','Home');
	}

	public function index()
	{
		$d = array(
					'judul' => 'Master',
					'sub_judul' => 'Transaksi - Nota Service',
					'class' => "nota_service",
					'setting' => $this->Home->get_setting(),
					'content'=> 'Buat Nota/view',
					);
        $this->load->view('Home/v_home',$d);
	}

	function get_list_dtNota()
	{
		$list = $this->Barang->get_dtBarang();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $person) {
			$no++;
			$row = array();
			$row[] = $person->kd_brg;
			$row[] = $person->nm_brg;
			$row[] = "Rp. ". number_format($person->harga,0,',','.');
			$row[] = $person->stok_brg.' '.$person->ket_satuan;
			$row[] = '
			<center>
				<a style="color:blue" href="javascript:void()" onclick="edit_barang('."'".$person->kd_brg."'".')" >
					<i class="fa fa-search-plus"></i>
				</a>
				&nbsp &nbsp
				<a style="color:red" href="javascript:void()" onclick="delete_barang('."'".$person->kd_brg."'".')">
					<i class="fa fa-trash"></i>
				</a>
			</center>
						';

			$data[] = $row; 
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->Barang->hitung_data(),
						"recordsFiltered" => $this->Barang->hitung_filter(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}
}