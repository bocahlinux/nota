<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Nota_penjualan extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('transaksi/m_penjualan','Penjualan');
		$this->load->model('home/mod_home','Home');
	}

	function index()
	{
		$d = array(
					'judul' => 'Master',
					'sub_judul' => 'Transaksi - Nota Penjualan',
					'judul_box' => 'Transaksi - Nota Penjualan',
					'class' => "buat_nota",
					'setting' => $this->Home->get_setting(),
					'barang' => $this->Penjualan->get(),
					'kd_tr' => $this->Penjualan->create_kd_penjualan(),
					'content'=> 'buat_nota/view',
					);
        $this->load->view('home/v_home',$d);
	}

	function getKode(){
		$d['kd_tr'] = $this->Penjualan->create_kd_penjualan();
		echo json_encode($d);
	}
	function getbarang($kd_brg)
	{
		$barang = $this->Penjualan->get_by_id($kd_brg);
		if ($barang)
			{
			if ($barang->stok_brg == '0')
			{
				$disabled = 'disabled';
				$info_stok = '<span class="help-block badge" id="reset"
					          style="background-color: #d9534f;">
					          stok habis</span>';
			}else{
				$disabled = '';
				$info_stok = '<span class="help-block badge" id="reset"
					          style="background-color: #5cb85c;">stok : '
					          .$barang->stok_brg.'</span>';
			}
			echo '<div class="form-group">
				      <label class="control-label col-md-3"
				      	for="nama_barang">Nama Barang :</label>
				      <div class="col-md-8">
				        <input type="text" class="form-control reset"
				        	name="nama_barang" id="nama_barang"
				        	value="'.$barang->nm_brg.'"
				        	readonly="readonly">
				      </div>
				    </div>
				    <div class="form-group">
				      <label class="control-label col-md-3"
				      	for="harga_barang">Harga (Rp) :</label>
				      <div class="col-md-3">
				        <input type="text" class="form-control reset" id="harga_barang" name="harga_barang"
				        	value="'.number_format( $barang->harga, 0 ,
				        	 '' , '.' ).'" readonly="readonly">
				      </div>
				    </div>
				    <div class="form-group">
				      <label class="control-label col-md-3"
				      	for="qty">Quantity :</label>
				      <div class="col-md-2">
				        <input type="number" class="form-control reset"
				        	name="qty" placeholder="Isi qty..." autocomplete="off"
				        	id="qty" onchange="subTotal(this.value)"
				        	onkeyup="subTotal(this.value)" min="0"  onKeyPress="return checkSubmit(event)"
				        	max="'.$barang->stok_brg.'" '.$disabled.'>
				      </div>'.$info_stok.'
				    </div>';
	    }else{
	    	echo '<div class="form-group">
				      <label class="control-label col-md-3"
				      	for="nama_barang">Nama Barang :</label>
				      <div class="col-md-8">
				        <input type="text" class="form-control reset"
				        	name="nama_barang" id="nama_barang"
				        	readonly="readonly">
				      </div>
				    </div>
				    <div class="form-group">
				      <label class="control-label col-md-3"
				      	for="harga_barang">Harga (Rp) :</label>
				      <div class="col-md-8">
				        <input type="text" class="form-control reset"
				        	name="harga_barang" id="harga_barang"
				        	readonly="readonly">
				      </div>
				    </div>
				    <div class="form-group">
				      <label class="control-label col-md-3"
				      	for="qty">Quantity :</label>
				      <div class="col-md-4">
				        <input type="number" class="form-control reset"
				        	autocomplete="off" onchange="subTotal(this.value)"
				        	onkeyup="subTotal(this.value)" onKeyPress="return checkSubmit(event) id="qty" min="0"
				        	name="qty" placeholder="Isi qty...">
				      </div>
				    </div>';
	    }
	}

	function ajax_list_transaksi()
	{
		$data = array();
		$no = 1;
        foreach ($this->cart->contents() as $items){

			$row = array();
			$row[] = $no;
			$row[] = $items["id"];
			$row[] = $items["name"];
			$row[] = 'Rp. ' . number_format( $items['price'],
                    0 , '' , '.' ) . ',-';
			$row[] = $items["qty"];
			$row[] = 'Rp. ' . number_format( $items['subtotal'],
					0 , '' , '.' ) . ',-';

			//add html for action
			$row[] = '<a
				href="javascript:void()" style="color:rgb(255,128,128);
				text-decoration:none" onclick="deletebarang('
					."'".$items["rowid"]."'".','."'".$items['subtotal'].
					"'".')">

						<button type="button" class="btn btn-xs btn-danger">
						      		  <i class="fa fa-close"></i> Delete</button>
					</a>';
			$data[] = $row;
			$no++;
        }

		$output = array(
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}

	function addbarang()
	{
		$data = array(
				'id' => $this->input->post('kd_brg'),
				'name' => $this->input->post('nama_barang'),
				'price' => str_replace('.', '', $this->input->post('harga_barang')),
				'qty' => $this->input->post('qty')
			);
		$insert = $this->cart->insert($data);
		echo json_encode(array("status" => TRUE));
	}

	function deletebarang($rowid)
	{
		$this->cart->update(array(
				'rowid'=>$rowid,
				'qty'=>0,));
		echo json_encode(array("status" => TRUE));
	}

	function simpan_dt_penjualan()
	{

		$d = array(
					'judul' => 'Master',
					'sub_judul' => 'Transaksi - Nota Penjualan',
					'judul_box' => 'Transaksi - Nota Penjualan',
					'class' => "buat_nota",
					'setting' => $this->Home->get_setting(),
					'barang' => $this->Penjualan->get(),
					'kd_tr' => $this->Penjualan->create_kd_penjualan(),
					'content'=> 'buat_nota/view',
					);

					$kode_trans			=		$this->input->post('kd_transaksi');
					$tgl_transaksi 	= 	strtotime(date('d-m-Y H:i:s'));
					$kd_pelanggan 	=		'-';
					$total					=		$this->input->post('total');
					$bayar					=		$this->input->post('bayar');
					$ket_transaksi	=		'-';

					if($bayar==0)
					{
						echo "Bayar Tidak Boleh bernilai 0";
					}
					else
					{
						$q = "insert into tbl_penjualan_header(kd_transaksi,tgl_transaksi,kd_pelanggan,total,bayar,ket_transaksi)
									values('".$kode_trans."','".$tgl_transaksi."','".$kd_pelanggan."','".$total."','".$bayar."','".$ket_transaksi."')";
						$this->Penjualan->simpan_penjualan($q);
						foreach($this->cart->contents() as $items)
						{
							$this->Penjualan->simpan_penjualan("insert into tbl_penjualan_detail (kd_transaksi,kd_brg,nm_brg,harga,jumlah) values('".$kode_trans."','".$items['id']."','".$items['name']."','".$items['price']."','".$items['qty']."')");
						}
						//echo "<meta http-equiv='refresh' content='0; url=".base_url()."Transaksi/Nota_penjualan'>";
						echo "Data Sukses diSimpan";
						$this->cart->destroy();
					}

	}
}
